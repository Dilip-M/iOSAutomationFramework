//
//  TwitterData.swift
//  iOSAutomationFrameworkUITests
//
//  Created by Mani, Dilip on 19/04/20.
//  Copyright © 2020 Mani, Dilip. All rights reserved.
//

import Foundation

public enum TwitterData {
    static let welcomeText = "See what’s happening in the world right now."
    static let twitter = "Twitter"
    static let userName = "QEnginner"
    static let password = "Testing99"
    static let searchText = "#TwitterIndia"
    static let message = "#twitterindia be at home"
    static let verifyMessage = "hash tag twitterindia be at home"
    static let tweetedPage = "twitterindia"
}
