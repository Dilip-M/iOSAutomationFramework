//
//  ViewController.swift
//  iOSAutomationFramework
//
//  Created by Mani, Dilip on 18/04/20.
//  Copyright © 2020 Mani, Dilip. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

